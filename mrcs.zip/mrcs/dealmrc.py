import numpy as np
import pylab as plt
from matplotlib import gridspec
from pylab import *
import matplotlib
import sys

spec="mcf"
index="3"
if len(sys.argv) > 2:
	spec=sys.argv[1]
	index=sys.argv[2]

spec_name= spec + "." + index
file_name=spec_name + ".txt"
pdf_name=spec + ".pdf"
png_name=spec_name + ".png"

index=[]
value=[]
rate=[]

sum = 0.0
cur = 0.0

print file_name
with open(file_name,"r") as fp:
	for line in fp:
		c = line[0]
		if c=='A' or c=='#':
			continue
		items=line.split(',')
		temp = float(items[1])
		if temp > 0:
			sum += float(items[1])
			index.append( float(items[0]) )
			value.append( float(items[1]) )
for i in range( len(index) ):
	cur += value[i]
	temp = 1 - cur/sum
	index[i] /= 8.0
	rate.append(temp)

ax1 = subplot(1,1,1)
plt.sca(ax1)
plt.plot(index, rate)

plt.xlim(-10)
plt.ylim(-.01)
plt.xlabel('Memory[MB]')
plt.ylabel('Miss Ratio')

# plt.show()
plt.savefig(png_name)

