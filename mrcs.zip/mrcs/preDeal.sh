# #Define an array and visit everyone

# array=(
# "astar"
# "bzip2"
# "bwaves"
# "gcc"
# "mcf"
# "zeusmp"
# "cactus"
# "gemsfdtd"
# "lbm"
# )
# len=${#array[@]}
# for((i=0;i<$len;i++))
# do
# 	echo i=$i ${array[$i]}
# done
# *********************************************************************************
array=(
"astar"
"bzip2"
"bwaves"
"gcc"
"mcf"
"zeusmp"
"cactus"
#"gemsfdtd"
"lbm"
)
rm -rf *.pdf
rm -rf *.png
len=${#array[@]}
for((i=0;i<$len;i++))
do
	echo ${array[$i]}
	number=`ls -l | grep ${array[$i]} | wc -l`
	echo $number "of"  ${array[$i]}
	for((j=1;j<=number;j++))
	do
		echo "dealmrc.py" ${array[$i]} $j
		python dealmrc.py ${array[$i]} $j
		#ls ${array[$i]}.$j.txt
	done
done
